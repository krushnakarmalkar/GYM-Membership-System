import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Member {
    private String name;
    private int age;
    private String gender;
    private String phone;
    private String email;

    public Member(String name, int age, String gender, String phone, String email) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.phone = phone;
        this.email = email;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }

    public boolean saveToDatabase() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO members (name, age, gender, phone, email) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setInt(2, age);
            stmt.setString(3, gender);
            stmt.setString(4, phone);
            stmt.setString(5, email);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error saving member: " + e.getMessage());
            return false;
        }
    }

    public static List<String> getAllMembers() {
        List<String> members = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM members";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("member_id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String gender = rs.getString("gender");
                String phone = rs.getString("phone");
                String email = rs.getString("email");
                members.add("ID: " + id + " | Name: " + name + " | Age: " + age +
                        " | Gender: " + gender + " | Phone: " + phone + " | Email: " + email);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching members: " + e.getMessage());
        }
        return members;
    }
}
