import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MembershipPlan {
    private int planId;
    private String planName;
    private int duration; // in months
    private double price;

    public MembershipPlan(int planId, String planName, int duration, double price) {
        this.planId = planId;
        this.planName = planName;
        this.duration = duration;
        this.price = price;
    }

    public int getPlanId() { return planId; }
    public String getPlanName() { return planName; }
    public int getDuration() { return duration; }
    public double getPrice() { return price; }

    public boolean saveToDatabase() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO membership_plans (plan_id, plan_name, duration, price) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, planId);
            stmt.setString(2, planName);
            stmt.setInt(3, duration);
            stmt.setDouble(4, price);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error saving plan: " + e.getMessage());
            return false;
        }
    }

    public static List<String> getAllPlans() {
        List<String> plans = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM membership_plans";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("plan_id");
                String name = rs.getString("plan_name");
                int duration = rs.getInt("duration");
                double price = rs.getDouble("price");
                plans.add("ID: " + id + " | Name: " + name + " | Duration: " + duration +
                        " months | Price: ₹" + price);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching plans: " + e.getMessage());
        }
        return plans;
    }
}
