import java.util.Scanner;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MemberPlan memberPlan = new MemberPlan();

        while (true) {
            System.out.println("\n=== GYM MEMBERSHIP SYSTEM ===");
            System.out.println("1. Add Member");
            System.out.println("2. View All Members");
            System.out.println("3. Add Membership Plan");
            System.out.println("4. View All Plans");
            System.out.println("5. Assign Plan to Member");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    // Add Member
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Age: ");
                    int age = sc.nextInt(); sc.nextLine();
                    System.out.print("Gender: ");
                    String gender = sc.nextLine();
                    System.out.print("Phone: ");
                    String phone = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();

                    Member member = new Member(name, age, gender, phone, email);
                    if (member.saveToDatabase()) {
                        System.out.println("Member added successfully.");
                    } else {
                        System.out.println("Failed to add member.");
                    }
                    break;

                case 2:
                    // View Members
                    List<String> members = Member.getAllMembers();
                    if (members.isEmpty()) {
                        System.out.println("No members found.");
                    } else {
                        System.out.println("Member List:");
                        members.forEach(System.out::println);
                    }
                    break;

                case 3:

                    System.out.print("Plan ID: ");
                    int planId = sc.nextInt(); sc.nextLine();
                    System.out.print("Plan Name: ");
                    String planName = sc.nextLine();
                    System.out.print("Duration (months): ");
                    int duration = sc.nextInt(); sc.nextLine();
                    System.out.print("Price: ");
                    double price = sc.nextDouble(); sc.nextLine();

                    MembershipPlan plan = new MembershipPlan(planId, planName, duration, price);
                    if (plan.saveToDatabase()) {
                        System.out.println("Plan added successfully.");
                    } else {
                        System.out.println("Failed to add plan.");
                    }
                    break;

                case 4:

                    List<String> plans = MembershipPlan.getAllPlans();
                    if (plans.isEmpty()) {
                        System.out.println("No plans found.");
                    } else {
                        System.out.println("Plan List:");
                        plans.forEach(System.out::println);
                    }
                    break;

                case 5:

                    System.out.println("Available Members:");
                    Member.getAllMembers().forEach(System.out::println);

                    System.out.println("Available Plans:");
                    MembershipPlan.getAllPlans().forEach(System.out::println);

                    System.out.print("Enter Member ID: ");
                    int memberId = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter Plan ID: ");
                    int planToAssign = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter Start Date (YYYY-MM-DD): ");
                    String startDate = sc.nextLine();


                    boolean assigned = memberPlan.assignPlanToMember(memberId, planToAssign, startDate);

                    if (assigned) {
                        System.out.println("Plan assigned to member.");
                    } else {
                        System.out.println("Failed to assign plan.");
                    }
                    break;

                case 6:
                    System.out.println("Thank you for using the Gym System. Goodbye!");
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
